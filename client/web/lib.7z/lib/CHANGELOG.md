# 更新日志

本文档记录 MuseumAgent Web 客户端 SDK 的所有重要变更。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

---

## [1.0.0] - 2026-02-19

### 🎉 首次发布

这是 MuseumAgent Web 客户端 SDK 的首个正式版本，完成了从原 Demo 项目到通用库的重构。

### ✨ 新增功能

#### 核心库
- **WebSocket 客户端** (`MuseumAgentClient.js`)
  - 完整的 WebSocket 连接管理
  - 自动重连机制
  - 心跳保活（120秒超时）
  - 会话管理（注册、查询、断开）
  - 协议实现（REGISTER、REQUEST、INTERRUPT、SHUTDOWN）
  - 流式传输支持（文本流、语音流）
  - 打断机制（客户端/服务端双向）

- **音频管理器** (`AudioManager.js`)
  - 录音功能（支持 VAD 自动检测）
  - 播放功能（支持流式播放）
  - VAD 语音活动检测
  - PCM 音频格式处理
  - 流式音频播放器（边接收边播放）

- **主 SDK 类** (`MuseumAgentSDK.js`)
  - 统一的 API 接口
  - 事件驱动架构
  - 简单易用的配置
  - 完整的生命周期管理

#### 事件系统
- `CONNECTED` - 连接成功
- `DISCONNECTED` - 连接断开
- `CONNECTION_ERROR` - 连接错误
- `SESSION_EXPIRED` - 会话过期
- `MESSAGE_SENT` - 消息已发送
- `TEXT_CHUNK` - 文本流
- `VOICE_CHUNK` - 语音流
- `MESSAGE_COMPLETE` - 消息完成
- `MESSAGE_ERROR` - 消息错误
- `RECORDING_START` - 录音开始
- `RECORDING_STOP` - 录音停止
- `RECORDING_ERROR` - 录音错误
- `SPEECH_START` - 语音开始（VAD）
- `SPEECH_END` - 语音结束（VAD）
- `FUNCTION_CALL` - 函数调用
- `INTERRUPTED` - 请求被打断

#### 文档
- 完整的 API 文档（70+ 页）
- 快速开始指南
- 项目结构说明
- Vue/React 集成示例
- 常见问题解答

#### 示例项目
- **Demo-Simple**: 单文件简单示例
- **Demo**: 完整功能参考实现

### 🎯 核心特性

- ✅ **零依赖**: 纯原生 JavaScript 实现
- ✅ **开箱即用**: 简单的 API，快速上手
- ✅ **高度聚合**: 所有功能集成到一个库
- ✅ **流式传输**: 边接收边处理，无延迟
- ✅ **打断机制**: 智能打断，无缝切换
- ✅ **VAD 检测**: 自动检测语音开始/结束
- ✅ **事件驱动**: 灵活的事件系统
- ✅ **类型安全**: 清晰的 API 设计

### 🔧 技术细节

#### WebSocket 协议
- 完整实现 CommunicationProtocol_CS.md 协议规范
- 支持文本和语音的流式传输
- 支持 BINARY 模式的语音数据传输
- 支持函数调用（Function Calling）

#### 音频处理
- 采样率: 16kHz
- 格式: PCM 16-bit mono
- VAD 参数可配置
- 流式播放无缝衔接

#### 浏览器兼容性
- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+

### 📦 文件结构

```
lib/
├── MuseumAgentClient.js    # WebSocket 客户端 + 事件总线
├── AudioManager.js          # 音频管理器
├── MuseumAgentSDK.js       # 主 SDK 类
├── README.md                # 完整 API 文档
├── package.json             # NPM 包配置
└── CHANGELOG.md             # 本文件
```

### 🚀 使用方式

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    autoPlay: true
});

await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

await client.sendText('你好');
```

### 📝 已知问题

- 无

### 🔮 未来计划

- [ ] TypeScript 类型定义
- [ ] 单元测试
- [ ] 性能优化
- [ ] 更多示例项目
- [ ] 国际化支持

---

## [Unreleased]

### 计划中的功能

- TypeScript 支持
- 更多的音频格式支持
- 离线模式
- 消息缓存
- 重连策略优化

---

## 版本说明

### 版本号规则

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/) 规范：

- **主版本号（MAJOR）**: 不兼容的 API 变更
- **次版本号（MINOR）**: 向后兼容的功能新增
- **修订号（PATCH）**: 向后兼容的问题修正

### 变更类型

- `新增` - 新功能
- `变更` - 现有功能的变更
- `废弃` - 即将移除的功能
- `移除` - 已移除的功能
- `修复` - Bug 修复
- `安全` - 安全相关的修复

---

## 贡献

欢迎提交 Issue 和 Pull Request！

---

## 许可证

MIT License

---

**最后更新**: 2026-02-19

