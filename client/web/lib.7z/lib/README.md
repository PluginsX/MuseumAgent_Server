# MuseumAgent Web 客户端 SDK 使用教程

版本：1.0.0

## 📖 简介

MuseumAgent Web 客户端 SDK 是一个开箱即用的智能体客户端库，封装了所有与 MuseumAgent 服务端通信所需的核心功能。

### 核心特性

- ✅ **WebSocket 连接管理**：自动重连、心跳保活
- ✅ **会话管理**：注册、查询、断开
- ✅ **消息收发**：文本、语音、流式传输
- ✅ **音频处理**：录音、播放、VAD 语音检测
- ✅ **打断机制**：客户端/服务端双向打断
- ✅ **事件系统**：解耦通信，灵活扩展
- ✅ **流式播放**：边接收边播放，无延迟

---

## 🚀 快速开始

### 1. 引入 SDK

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';
```

### 2. 创建客户端实例

```javascript
const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    enableSRS: true,
    autoPlay: true,
    onTextChunk: (data) => {
        console.log('收到文本:', data.chunk);
    },
    onVoiceChunk: (data) => {
        console.log('收到语音:', data.audioData);
    },
    onError: (error) => {
        console.error('错误:', error);
    }
});
```

### 3. 连接到服务器

```javascript
// 使用账户密码登录
await client.connect({
    type: 'ACCOUNT',
    account: 'username',
    password: 'password'
});

// 或使用 API Key 登录
await client.connect({
    type: 'API_KEY',
    api_key: 'your-api-key'
});
```

### 4. 发送消息

```javascript
// 发送文本消息
await client.sendText('你好，请介绍一下博物馆');

// 开始录音
await client.startRecording();

// 停止录音并发送
await client.stopRecording();
```

---

## 📚 详细 API 文档

### 构造函数

```javascript
new MuseumAgentClient(config)
```

**参数 `config`：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `serverUrl` | string | `'ws://localhost:8001'` | 服务器地址 |
| `platform` | string | `'WEB'` | 平台标识 |
| `requireTTS` | boolean | `true` | 是否需要 TTS 语音合成 |
| `enableSRS` | boolean | `true` | 是否启用语义检索 |
| `autoPlay` | boolean | `true` | 是否自动播放语音 |
| `vadEnabled` | boolean | `true` | 是否启用 VAD 语音检测 |
| `functionCalling` | array | `[]` | 函数调用配置 |
| `vadParams` | object | 见下文 | VAD 参数配置 |
| `onTextChunk` | function | - | 文本流回调 |
| `onVoiceChunk` | function | - | 语音流回调 |
| `onMessageComplete` | function | - | 消息完成回调 |
| `onError` | function | - | 错误回调 |
| `onFunctionCall` | function | - | 函数调用回调 |
| `onSpeechStart` | function | - | 语音开始回调（VAD） |
| `onSpeechEnd` | function | - | 语音结束回调（VAD） |

**VAD 参数配置：**

```javascript
vadParams: {
    silenceThreshold: 0.01,      // 静音阈值
    silenceDuration: 800,         // 静音持续时长（毫秒）
    speechThreshold: 0.02,        // 语音阈值
    minSpeechDuration: 200,       // 最小语音时长（毫秒）
    preSpeechPadding: 150,        // 语音前填充（毫秒）
    postSpeechPadding: 300        // 语音后填充（毫秒）
}
```

---

### 核心方法

#### `connect(authData)`

连接到服务器并注册会话。

```javascript
// 账户密码登录
await client.connect({
    type: 'ACCOUNT',
    account: 'username',
    password: 'password'
});

// API Key 登录
await client.connect({
    type: 'API_KEY',
    api_key: 'your-api-key'
});
```

**返回值：** `Promise<Object>` - 会话信息

---

#### `disconnect(reason)`

断开连接。

```javascript
await client.disconnect('用户主动退出');
```

---

#### `sendText(text, options)`

发送文本消息。

```javascript
await client.sendText('你好', {
    requireTTS: true,
    enableSRS: true,
    functionCalling: [
        {
            name: 'play_animation',
            description: '播放动画',
            parameters: [
                { name: 'animation_name', type: 'string', description: '动画名称' }
            ]
        }
    ]
});
```

**参数：**
- `text` (string): 文本内容
- `options` (object): 可选配置
  - `requireTTS` (boolean): 是否需要 TTS
  - `enableSRS` (boolean): 是否启用语义检索
  - `functionCalling` (array): 函数调用配置

---

#### `startRecording(options)`

开始录音。

```javascript
// 启用 VAD（自动检测语音开始/结束）
await client.startRecording({
    vadEnabled: true,
    vadParams: {
        silenceThreshold: 0.01,
        silenceDuration: 800,
        speechThreshold: 0.02,
        minSpeechDuration: 200,
        preSpeechPadding: 150,
        postSpeechPadding: 300
    }
});

// 不启用 VAD（手动控制）
await client.startRecording({
    vadEnabled: false
});
```

---

#### `stopRecording()`

停止录音。

```javascript
await client.stopRecording();
```

---

#### `interrupt(reason)`

打断当前请求。

```javascript
await client.interrupt('USER_NEW_INPUT');
```

---

#### `playAudio(pcmData, sampleRate)`

播放音频。

```javascript
await client.playAudio(pcmData, 16000);
```

---

#### `stopPlayback()`

停止播放。

```javascript
client.stopPlayback();
```

---

### 事件系统

#### `on(event, callback)`

订阅事件。

```javascript
client.on(Events.TEXT_CHUNK, (data) => {
    console.log('文本块:', data.chunk);
});
```

#### `off(event, callback)`

取消订阅。

```javascript
const handler = (data) => console.log(data);
client.on(Events.TEXT_CHUNK, handler);
client.off(Events.TEXT_CHUNK, handler);
```

#### `once(event, callback)`

订阅一次性事件。

```javascript
client.once(Events.MESSAGE_COMPLETE, (data) => {
    console.log('消息完成:', data);
});
```

---

### 事件列表

| 事件名 | 说明 | 数据 |
|--------|------|------|
| `Events.CONNECTED` | 连接成功 | `{ session_id, ... }` |
| `Events.DISCONNECTED` | 连接断开 | - |
| `Events.CONNECTION_ERROR` | 连接错误 | `Error` |
| `Events.SESSION_EXPIRED` | 会话过期 | `{ error_code, error_msg }` |
| `Events.MESSAGE_SENT` | 消息已发送 | `{ id, type, content }` |
| `Events.TEXT_CHUNK` | 文本流 | `{ messageId, chunk }` |
| `Events.VOICE_CHUNK` | 语音流 | `{ messageId, audioData, seq }` |
| `Events.MESSAGE_COMPLETE` | 消息完成 | `{ messageId }` |
| `Events.MESSAGE_ERROR` | 消息错误 | `Error` |
| `Events.RECORDING_START` | 录音开始 | - |
| `Events.RECORDING_STOP` | 录音停止 | - |
| `Events.RECORDING_ERROR` | 录音错误 | `Error` |
| `Events.SPEECH_START` | 语音开始（VAD） | - |
| `Events.SPEECH_END` | 语音结束（VAD） | - |
| `Events.FUNCTION_CALL` | 函数调用 | `{ name, arguments }` |
| `Events.INTERRUPTED` | 请求被打断 | `{ messageId, reason }` |

---

## 💡 完整示例

### 示例 1：简单的文本对话

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: false,
    autoPlay: false
});

// 连接
await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

// 监听文本流
let fullText = '';
client.on(Events.TEXT_CHUNK, (data) => {
    fullText += data.chunk;
    console.log('当前文本:', fullText);
});

// 监听消息完成
client.on(Events.MESSAGE_COMPLETE, () => {
    console.log('完整回复:', fullText);
    fullText = '';
});

// 发送消息
await client.sendText('你好，请介绍一下博物馆');
```

---

### 示例 2：语音对话（启用 VAD）

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    autoPlay: true,
    vadEnabled: true
});

// 连接
await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

// 监听语音检测事件
client.on(Events.SPEECH_START, () => {
    console.log('检测到语音开始');
});

client.on(Events.SPEECH_END, () => {
    console.log('检测到语音结束');
});

// 监听文本流
client.on(Events.TEXT_CHUNK, (data) => {
    console.log('AI 回复:', data.chunk);
});

// 开始录音（VAD 会自动检测语音开始/结束）
await client.startRecording();

// 用户可以随时手动停止录音
// await client.stopRecording();
```

---

### 示例 3：语音对话（手动控制）

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    autoPlay: true,
    vadEnabled: false  // 关闭 VAD
});

// 连接
await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

// 按钮点击开始录音
document.getElementById('recordBtn').addEventListener('click', async () => {
    if (!client.isRecording) {
        await client.startRecording({ vadEnabled: false });
        console.log('开始录音');
    } else {
        await client.stopRecording();
        console.log('停止录音');
    }
});
```

---

### 示例 4：函数调用

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    functionCalling: [
        {
            name: 'play_animation',
            description: '播放动画',
            parameters: [
                { name: 'animation_name', type: 'string', description: '动画名称' }
            ]
        }
    ]
});

// 连接
await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

// 监听函数调用
client.on(Events.FUNCTION_CALL, (functionCall) => {
    console.log('函数调用:', functionCall.name);
    console.log('参数:', functionCall.arguments);
    
    // 执行函数
    if (functionCall.name === 'play_animation') {
        const animationName = functionCall.arguments.animation_name;
        playAnimation(animationName);
    }
});

// 发送消息
await client.sendText('让宠物跳舞');
```

---

### 示例 5：打断机制

```javascript
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    autoPlay: true
});

// 连接
await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
});

// 监听打断事件
client.on(Events.INTERRUPTED, (data) => {
    console.log('请求被打断:', data.reason);
});

// 发送第一个消息
await client.sendText('请详细介绍一下博物馆的历史');

// 等待 1 秒后打断
setTimeout(async () => {
    await client.sendText('不用介绍了，直接告诉我开放时间');
}, 1000);
```

---

## 🎨 与 UI 框架集成

### Vue 3 示例

```vue
<template>
  <div>
    <div v-for="msg in messages" :key="msg.id">
      {{ msg.content }}
    </div>
    <input v-model="inputText" @keyup.enter="sendMessage" />
    <button @click="toggleRecording">
      {{ isRecording ? '停止录音' : '开始录音' }}
    </button>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

const messages = ref([]);
const inputText = ref('');
const isRecording = ref(false);
let client = null;

onMounted(async () => {
  client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    requireTTS: true,
    autoPlay: true
  });
  
  await client.connect({
    type: 'ACCOUNT',
    account: 'test',
    password: '123456'
  });
  
  client.on(Events.MESSAGE_SENT, (data) => {
    messages.value.push({
      id: data.id,
      type: 'sent',
      content: data.content
    });
  });
  
  let currentMessage = null;
  client.on(Events.TEXT_CHUNK, (data) => {
    if (!currentMessage) {
      currentMessage = {
        id: data.messageId,
        type: 'received',
        content: data.chunk
      };
      messages.value.push(currentMessage);
    } else {
      currentMessage.content += data.chunk;
    }
  });
  
  client.on(Events.MESSAGE_COMPLETE, () => {
    currentMessage = null;
  });
});

onUnmounted(() => {
  client?.cleanup();
});

const sendMessage = async () => {
  if (!inputText.value.trim()) return;
  await client.sendText(inputText.value);
  inputText.value = '';
};

const toggleRecording = async () => {
  if (isRecording.value) {
    await client.stopRecording();
    isRecording.value = false;
  } else {
    await client.startRecording();
    isRecording.value = true;
  }
};
</script>
```

---

### React 示例

```jsx
import React, { useState, useEffect, useRef } from 'react';
import { MuseumAgentClient, Events } from './lib/MuseumAgentSDK.js';

function ChatApp() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const clientRef = useRef(null);
  
  useEffect(() => {
    const initClient = async () => {
      const client = new MuseumAgentClient({
        serverUrl: 'ws://localhost:8001',
        requireTTS: true,
        autoPlay: true
      });
      
      await client.connect({
        type: 'ACCOUNT',
        account: 'test',
        password: '123456'
      });
      
      client.on(Events.MESSAGE_SENT, (data) => {
        setMessages(prev => [...prev, {
          id: data.id,
          type: 'sent',
          content: data.content
        }]);
      });
      
      let currentMessage = null;
      client.on(Events.TEXT_CHUNK, (data) => {
        setMessages(prev => {
          if (!currentMessage) {
            currentMessage = {
              id: data.messageId,
              type: 'received',
              content: data.chunk
            };
            return [...prev, currentMessage];
          } else {
            const updated = [...prev];
            const index = updated.findIndex(m => m.id === data.messageId);
            if (index !== -1) {
              updated[index].content += data.chunk;
            }
            return updated;
          }
        });
      });
      
      client.on(Events.MESSAGE_COMPLETE, () => {
        currentMessage = null;
      });
      
      clientRef.current = client;
    };
    
    initClient();
    
    return () => {
      clientRef.current?.cleanup();
    };
  }, []);
  
  const sendMessage = async () => {
    if (!inputText.trim()) return;
    await clientRef.current.sendText(inputText);
    setInputText('');
  };
  
  const toggleRecording = async () => {
    if (isRecording) {
      await clientRef.current.stopRecording();
      setIsRecording(false);
    } else {
      await clientRef.current.startRecording();
      setIsRecording(true);
    }
  };
  
  return (
    <div>
      <div>
        {messages.map(msg => (
          <div key={msg.id}>{msg.content}</div>
        ))}
      </div>
      <input 
        value={inputText} 
        onChange={(e) => setInputText(e.target.value)}
        onKeyUp={(e) => e.key === 'Enter' && sendMessage()}
      />
      <button onClick={toggleRecording}>
        {isRecording ? '停止录音' : '开始录音'}
      </button>
    </div>
  );
}

export default ChatApp;
```

---

## 🔧 高级配置

### 自定义 VAD 参数

```javascript
const client = new MuseumAgentClient({
    serverUrl: 'ws://localhost:8001',
    vadEnabled: true,
    vadParams: {
        silenceThreshold: 0.005,    // 更低的静音阈值（更敏感）
        silenceDuration: 1000,       // 更长的静音时长（更晚结束）
        speechThreshold: 0.03,       // 更高的语音阈值（更不敏感）
        minSpeechDuration: 300,      // 更长的最小语音时长
        preSpeechPadding: 200,       // 更多的前填充
        postSpeechPadding: 400       // 更多的后填充
    }
});
```

### 动态更新配置

```javascript
// 发送消息时临时修改配置
await client.sendText('你好', {
    requireTTS: false,  // 本次不需要 TTS
    enableSRS: false,   // 本次不启用语义检索
    functionCalling: [] // 本次不启用函数调用
});
```

---

## 📝 注意事项

1. **浏览器兼容性**：需要支持 WebSocket、AudioContext、MediaDevices API
2. **HTTPS 要求**：在生产环境中，录音功能需要 HTTPS 协议
3. **用户交互**：AudioContext 需要在用户交互后才能初始化（如点击按钮）
4. **资源清理**：组件卸载时务必调用 `client.cleanup()` 清理资源
5. **错误处理**：建议监听所有错误事件并妥善处理

---

## 🐛 常见问题

### Q: 为什么录音功能无法使用？

A: 请确保：
1. 浏览器支持 MediaDevices API
2. 网站使用 HTTPS 协议（或 localhost）
3. 用户已授权麦克风权限

### Q: 为什么音频无法播放？

A: 请确保：
1. AudioContext 已在用户交互后初始化
2. 浏览器未静音
3. `autoPlay` 配置正确

### Q: 如何实现打断功能？

A: SDK 已内置打断机制，发送新消息时会自动打断当前响应。也可以手动调用 `client.interrupt()`。

### Q: 如何保存会话？

A: 可以保存 `client.session` (sessionId) 到 localStorage，下次连接时使用相同的认证信息即可恢复会话。

---

## 📄 许可证

MIT License

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

---

## 📧 联系方式

如有问题，请联系开发团队。

